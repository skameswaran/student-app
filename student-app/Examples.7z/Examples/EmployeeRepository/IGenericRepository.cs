﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeRepository
{
    interface IGenericRepository<T> where T : class
    {
        IEnumerable<T> GetAllRecords();
        void AddRecord(T entity);
        void Update(T entity);
        void Delete(T entity);

        T GetFirstOrDefault(int id);
    }
}
