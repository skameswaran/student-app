﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeRepository
{
    public class GenericRepository<T> : IGenericRepository<T> where T : class
    {
        DbSet<T> _dbset;
        EmployeeEntities.EmployeeEntities _dbContext;

        public GenericRepository(EmployeeEntities.EmployeeEntities dbcontext)
        {
            _dbContext = dbcontext;
            _dbset = _dbContext.Set<T>();
        }
        public IEnumerable<T> GetAllRecords()
        {
            return _dbset.ToList();
        }

        public void AddRecord(T entity)
        {
            _dbset.Add(entity);
        }

        public void Update(T entity)
        {
            _dbset.Attach(entity);
            _dbContext.Entry(entity).State = EntityState.Modified;
        }


        public void Delete(T entity)
        {

            if (_dbContext.Entry(entity).State == EntityState.Detached)
                _dbset.Attach(entity);
            _dbset.Remove(entity);
        }


        public T GetFirstOrDefault(int id)
        {
            return _dbset.Find(id);
        }
    }
}
