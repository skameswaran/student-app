﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace EmployeeRepository
{
    public class UnitOfWork : IDisposable
    {
        EmployeeEntities.EmployeeEntities _dbContext =
            new EmployeeEntities.EmployeeEntities();

        public GenericRepository<T> GetRepositoryInstance<T>() where T : class
        {
            return new GenericRepository<T>(_dbContext);
        }

        public void SaveChanges()
        {
            _dbContext.SaveChanges();
        }

        public void Dispose()
        {
            if (_dbContext != null)
                _dbContext.Dispose();
        }
    }
}
