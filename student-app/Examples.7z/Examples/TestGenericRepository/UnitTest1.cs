﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using EmployeeRepository;

namespace TestGenericRepository
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestGetAllEmployees()
        {
            UnitOfWork _unitofwork =
                new UnitOfWork();
            var emplList = _unitofwork.GetRepositoryInstance<EmployeeEntities.Employee>().GetAllRecords();

        }

        [TestMethod]
        public void TestAddEmployee()
        {
            EmployeeEntities.Employee record =
                new EmployeeEntities.Employee();
            record.FirstName = "kameswaran";
            record.LastName = "sethuraman";
            record.MiddleName = string.Empty;
            UnitOfWork _unitofwork =
                new UnitOfWork();
            _unitofwork.GetRepositoryInstance<EmployeeEntities.Employee>().AddRecord(record);
            _unitofwork.SaveChanges();
        }

        [TestMethod]
        public void TestUpdateEmployee()
        {
            EmployeeEntities.Employee record =
                new EmployeeEntities.Employee();
            record.EmployeeID = 2;
            record.FirstName = "Kameswaran";
            record.LastName = "Sethuraman";
            record.MiddleName = string.Empty;
            record.DepartmentCode = "D002";
            UnitOfWork _unitofwork =
                new UnitOfWork();
            _unitofwork.GetRepositoryInstance<EmployeeEntities.Employee>().Update(record);
            _unitofwork.SaveChanges();
        }


        [TestMethod]
        public void TestDeleteEmployee()
        {
            UnitOfWork _unitofwork =
                new UnitOfWork();
            EmployeeEntities.Employee recordtoDelete =
                _unitofwork.GetRepositoryInstance<EmployeeEntities.Employee>().GetFirstOrDefault(1);
            _unitofwork.GetRepositoryInstance<EmployeeEntities.Employee>().Delete(recordtoDelete);
            _unitofwork.SaveChanges();
        }
    }
}
